package com.hsbc.plugin.refresh;


import java.util.ArrayList;

import com.hsbc.plugin.utils.DiagramGenerator;
import com.vp.plugin.ApplicationManager;
import com.vp.plugin.DiagramManager;
import com.vp.plugin.ViewManager;
import com.vp.plugin.action.VPAction;
import com.vp.plugin.action.VPActionController;

public class GenerateWebDiagram  implements VPActionController {
	
	@Override
	public void performAction(VPAction arg0) {
		
		ApplicationManager.instance().reloadPluginClasses("com.hsbc.plugin");
		
		ViewManager viewManager = ApplicationManager.instance().getViewManager();
		DiagramManager diagramManager = ApplicationManager.instance().getDiagramManager();
		
		try {
			if(diagramManager.getActiveDiagram().getType().equals("GridDiagram")) {
				if(diagramManager.getActiveDiagram().getParentModel().getName().startsWith("$")) {
					//FilteredGridDiagramGenerator.GenerateFilteredGrid(diagramManager.getActiveDiagram());
				} else if(diagramManager.getActiveDiagram().getParentModel().getName().equals("Requirement")){
					//GenerateProjectGrids.generateRequirementsGrid(diagramManager.getActiveDiagram());
				} else if(diagramManager.getActiveDiagram().getParentModel().getName().equals("Stake Holders")){
					//GenerateProjectGrids.generateStakeHolderGrid(diagramManager.getActiveDiagram());
				} else {
					//GridDiagramGenerator.generateGridDiagramTable(diagramManager.getActiveDiagram());
				}
			} else {
				DiagramGenerator.generateImageMap(diagramManager.getActiveDiagram(), null);
			}
		} catch (Exception e) {
			e.printStackTrace();
			viewManager.showMessage("Unable to refresh diagram");
		}
		viewManager.showMessage("Diagram documentation updated for id:"+diagramManager.getActiveDiagram().getId());
	}

	@Override
	public void update(VPAction arg0) {
	}
}