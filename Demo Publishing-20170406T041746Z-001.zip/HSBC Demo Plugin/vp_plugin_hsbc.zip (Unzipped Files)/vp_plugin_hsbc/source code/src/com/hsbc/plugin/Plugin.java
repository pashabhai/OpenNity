package com.hsbc.plugin;



import com.vp.plugin.VPPlugin;
import com.vp.plugin.VPPluginInfo;





public class Plugin implements VPPlugin { 

	@Override
	public void loaded(VPPluginInfo aPluginInfo) {	
		
	}

	@Override
	public void unloaded() {
		
	}
}
