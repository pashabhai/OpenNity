package com.hsbc.plugin.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

public class HtmlTemplate {
	public static String loadFileContents(String fileName) {
		String template = "";
		
		InputStream input = null;
		try {
			StringBuffer buf = new StringBuffer();
			File fInput = new File(fileName);
			BufferedReader br = new BufferedReader(new FileReader(fInput));			
			String line = null;
			while ((line = br.readLine()) != null) {
				buf.append(line+"\n");
			}
			br.close();	
			template = buf.toString();
		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	 
		}		
		return template;		
	}
	
	public static void writeToFile(String path, String contents) {
		try {
			PrintWriter out = new PrintWriter(path);
			out.println(contents);
			out.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}	
}
