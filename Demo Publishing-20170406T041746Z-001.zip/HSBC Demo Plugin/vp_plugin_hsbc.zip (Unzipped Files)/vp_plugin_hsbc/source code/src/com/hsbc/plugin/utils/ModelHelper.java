package com.hsbc.plugin.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;
import java.util.TreeMap;

import com.vp.plugin.ApplicationManager;
import com.vp.plugin.ViewManager;
import com.vp.plugin.diagram.IDiagramUIModel;
import com.vp.plugin.model.IHasChildrenBaseModelElement;
import com.vp.plugin.model.IHasRelationshipBaseSimpleRelationship;
import com.vp.plugin.model.IModelElement;
import com.vp.plugin.model.INoChildrenBaseModelElement;
import com.vp.plugin.model.IProject;
import com.vp.plugin.model.IReference;

public class ModelHelper {
	
	public static IModelElement getChildOfParent(IModelElement el, String name) {
		IModelElement tmpEl = el.getParent();
		if(tmpEl!=null)
		{
			if(tmpEl.getName().equals(name))
				return el;
			else
				return getChildOfParent(tmpEl, name);
		}
		else
			return null;
	}
	
	public static IProject getProject(String strProj)
	{
		IProject project = ApplicationManager.instance().getProjectManager().getProject();
		if(project.getName().equalsIgnoreCase(strProj))
			return project;
		else
		{
			IProject[] proj = project.getLinkedProjects();
			
			if(proj!=null && proj.length!=0) {
				for(int iProj=0;iProj<proj.length;iProj++)
				{
					if(proj[iProj].getName().equalsIgnoreCase(strProj))
						return proj[iProj];
				}
			}	
		}
		return null;
	}	
	
	public static String getWebComponentsDirectory() {
		Properties prop = new Properties();
		String webCompDir = "";
		InputStream input = null;
		try {
			 
			input = new FileInputStream("../plugins/vp_plugin/lib/geopostuk.properties");
	
			prop.load(input);
	 
			webCompDir = prop.getProperty("webcomponent_source");
			
		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	 
		}		
		return webCompDir;
	}	
	
	public static String getSlackUsername() {
		Properties prop = new Properties();
		String webCompDir = "";
		InputStream input = null;
		try {
			 
			input = new FileInputStream("../plugins/vp_plugin/lib/geopostuk.properties");
	
			prop.load(input);
	 
			webCompDir = prop.getProperty("slack_username");
			
		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	 
		}		
		return webCompDir;
	}	
	
	public static String getEsgWebCustomerDirectory() {
		Properties prop = new Properties();
		String esgweb = "";
		InputStream input = null;
		try {
			 
			input = new FileInputStream("../plugins/vp_plugin/lib/geopostuk.properties");
	
			prop.load(input);
	 
			esgweb = prop.getProperty("esg_web_customer");
			
		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	 
		}		
		return esgweb;
	}		
	
	public static String getEsgWebInternalDirectory(String pluginDir) {
		Properties prop = new Properties();
		String esgweb = "";
		InputStream input = null;
		try {
			 
			input = new FileInputStream(pluginDir);
	
			prop.load(input);
	 
			esgweb = prop.getProperty("it_website");
			
		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	 
		}		
		return esgweb;
	}		
	
	public static String getEsgSourceDirectory() {
		Properties prop = new Properties();
		String source = "";
		InputStream input = null;
		try {
			 
			input = new FileInputStream("../plugins/vp_plugin/lib/geopostuk.properties");
	
			prop.load(input);
	 
			source = prop.getProperty("esgsource");
			
		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	 
		}		
		return source;
	}	
	
	public static String[] getProjectNames() {
		Properties prop = new Properties();
		String[] proj = new String[0];
		InputStream input = null;
		try {
			 
			input = new FileInputStream("../plugins/vp_plugin/lib/geopostuk.properties");
	
			prop.load(input);
	 
			String projects = prop.getProperty("projects");
			proj = projects.split(";");
			
		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	 
		}		
		return proj;
	}
	
	public static IModelElement getRootModel(String str, IProject project) {

		Iterator<IModelElement> iter = project.modelElementIterator("Model");
		IModelElement el = null;
		while (iter.hasNext())
		{
			el = iter.next();
			if(el.getName().equalsIgnoreCase(str))
				return el;
		}	
		return null;
	}
	
	public static IModelElement getModel(Collection<String> tree, IModelElement currentModel) {

		if(tree==null || tree.size()==0)
		{
			return currentModel;
		}
		
		//remove first name from list
		Collection<String> newTree = new ArrayList<String>();
		Iterator<String> i= tree.iterator();
		String str = "";
		IModelElement child = null;
		if(i.hasNext())
		{					
			str = i.next();
			child = currentModel.getChildByName(str);
			if(child==null)
				return null;
			if(i.hasNext()==false)
			{
				return child;
			}
		}
		
		//recreate list
		while (i.hasNext()) {
			newTree.add(i.next());
		}
		
		//still not at the bottom, get next element
		return getModel(newTree, child);
	}
	
	public static String loadFileContents(String fileName) {
		String template = "";
		
		InputStream input = null;
		try {
			StringBuffer buf = new StringBuffer();
			File fInput = new File(fileName);
			BufferedReader br = new BufferedReader(new FileReader(fInput));			
			String line = null;
			while ((line = br.readLine()) != null) {
				buf.append(line+"\n");
			}
			br.close();	
			template = buf.toString();
		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}		
		return template;		
	}
	
	public static String[] getITPersonnel() {
		IProject project = ApplicationManager.instance().getProjectManager().getProject();
		Collection<String> itPeople = new ArrayList<String>();
		Collection<String> domainTree = new ArrayList<String>();
		domainTree.add("Structure");
		IModelElement structureModel = ModelHelper.getModel(domainTree, ModelHelper.getRootModel("IT Department", project));
		IModelElement[] structureModels = structureModel.toChildArray("Model");
		for(int i =0 ; i<structureModels.length; i++) {
			IModelElement[] people = structureModels[i].toChildArray();
			for(IModelElement person : people) {
				if(person.getModelType().equals("OCUnit")) {
					itPeople.add(person.getName());
				}
				if(person.getModelType().equals("Model")) {
					IModelElement[] subPeople = person.toChildArray();
					for(IModelElement subPerson : subPeople) {
						if(person.getModelType().equals("OCUnit")) {
							itPeople.add(person.getName());
						}	
					}
				}
			}
		}
		
		Integer count = 0;
		for(String itPerson : itPeople) {
			count ++;
		}
		
		String[] people = new String[count];
		
		count = 0;
		for(String itPerson : itPeople) {
			people[count] = itPerson;
			count++;
		}
		Arrays.sort(people);
		
		return people;
	}
	
	public static IModelElement checkIfProjectOrChange (IModelElement model) {
		IModelElement activeModel = model;
		IModelElement changeOrProjectModel = null;
		if(activeModel.getParent() != null && activeModel.getParent().getName().equals("_Projects")) {
			changeOrProjectModel = activeModel;
		} else if(activeModel.getParent() != null && activeModel.getParent().getName().equals("_Changes")) {
			changeOrProjectModel = activeModel;
		} else if(activeModel.getParent() != null && activeModel.getParent().getName().equals("_Continual Projects")) {
			changeOrProjectModel = activeModel;
		} else {
			if(activeModel.getParent() != null) {
				changeOrProjectModel = checkIfProjectOrChange(activeModel.getParent());
			}
		}
		return changeOrProjectModel;
	}
	
	public static IModelElement checkRootModel(IModelElement model, String rootModelName) {
		IModelElement activeModel = model;
		IModelElement rootModel = null;
		if(activeModel.getParent() != null && activeModel.getParent().getName().equals(rootModelName)) {
			rootModel = activeModel.getParent();
		} else {
			if(activeModel.getParent() != null) {
				rootModel = checkRootModel(activeModel.getParent(), rootModelName);
			}
		}
		return rootModel;
	}
	
	public static IModelElement getRootModel(IModelElement model) {
		IModelElement activeModel = null;
		IModelElement rootModel = null;
		if(model != null) {
			activeModel = model;
			if(activeModel.getParent() != null) {
				rootModel = getRootModel(activeModel.getParent());
			} else {
				rootModel = activeModel;
			}
		}
		return rootModel;
	}
	
	public static IModelElement checkIfAsIsOrToBe (IModelElement model) {
		IModelElement activeModel = model;
		IModelElement asIsOrToBeModel = null;
		if(activeModel.getParent() != null && activeModel.getParent().getName().equals("As-Is")) {
			asIsOrToBeModel = activeModel.getParent();
		} else if(activeModel.getParent() != null && activeModel.getParent().getName().equals("To-Be")) {
			asIsOrToBeModel = activeModel.getParent();
		} else {
			if(activeModel.getParent() != null) {
				asIsOrToBeModel = checkIfAsIsOrToBe(activeModel.getParent());
			}
		}
		return asIsOrToBeModel;
	}
	
	public static Collection<IModelElement> getProjectsInVP() {
		IProject project = getProject("Solutions");
		System.out.println(project.getName());
		IModelElement changeModel = ModelHelper.getModel(null, ModelHelper.getRootModel("_Changes", project));
		IModelElement projectModel = ModelHelper.getModel(null, ModelHelper.getRootModel("_Projects", project));
		IModelElement productModel = ModelHelper.getModel(null, ModelHelper.getRootModel("_Continual Projects", project));
		IModelElement[] changeModels = changeModel.toChildArray("Model");
		IModelElement[] projectModels = projectModel.toChildArray("Model");
		IModelElement[] productModels = productModel.toChildArray("Model");
		Collection<IModelElement> allProjectsModels = new ArrayList<IModelElement>();

		for(int i =0; i<changeModels.length; i++) {
			if(!changeModels[i].getName().equals("_Archive")) {
				allProjectsModels.add(changeModels[i]);
			}
		}
		for(int i =0; i<projectModels.length; i++) {
			if(!projectModels[i].getName().equals("_Archive")) {
				allProjectsModels.add(projectModels[i]);
			}
		}
		for(int i =0; i<productModels.length; i++) {
			if(!productModels[i].getName().equals("_Archive")) {
				allProjectsModels.add(productModels[i]);
			}
		}
		
		return allProjectsModels;
		
	}
	
	public static TreeMap<String, IModelElement> getPeople(TreeMap<String, IModelElement> people, IModelElement peopleGroup) {
		IModelElement[] peopleInGroup = peopleGroup.toChildArray();
		if(peopleInGroup != null) {
			for(int i = 0; i<peopleInGroup.length; i++) {
				if(peopleInGroup[i].getModelType().equals("Model")) {
					getPeople(people, peopleInGroup[i]);
				}
				if(peopleInGroup[i].getModelType().equals("OCUnit")) {
					people.put(peopleInGroup[i].getName(), peopleInGroup[i]);
				}
			}
		}
		return people;
	}
	
	public static String getModelReferences(IModelElement model, String diagId) {
		String script = "";
		String clickEvent = "";
		String url = "";
		Boolean clickFound = false;
		IReference[] ref = null;
		
		try {
			IHasChildrenBaseModelElement childEl = null;
			childEl = ((IHasChildrenBaseModelElement)model);
			ref = childEl.toReferenceArray();
		} catch(Exception e) {
			//failed to cast
			try {
				IHasRelationshipBaseSimpleRelationship childEl = null;
				childEl = ((IHasRelationshipBaseSimpleRelationship)model);
				ref = childEl.toReferenceArray();
			} catch(Exception f) {
				//failed to cast
				try {
					INoChildrenBaseModelElement childEl = null;
					childEl = ((INoChildrenBaseModelElement)model);
					ref = childEl.toReferenceArray();	
				} catch(Exception g) {
					System.out.println("Problem casting to class type:"+model.getModelType());
					return "";
				}
			}
		}
		if(ref!=null)
		{
			for(int r=0;r<ref.length;r++)
			{
				if(ref[r].getType()==2)
				{
					IDiagramUIModel refDiag = ref[r].getUrlAsDiagram();

					//check diagram is active
					if(refDiag!=null)
					{
						if(!refDiag.getId().equals(diagId)) {
							//add diagram to pop up
							url += "/it/diagram/diag_" + refDiag.getId() + ".html";
							clickEvent += refDiag.getId()+"~"+refDiag.getName()+";";
							clickFound = true;
						}
					}
				}
				else if(ref[r].getType()==1)
				{
					String refDiag = ref[r].getUrl();

					//check diagram is active
					if(refDiag!=null)
					{
						//add diagram to pop up
						clickEvent += refDiag+";";
					}		
					clickFound = true;
				}							
			}
				script = "<script>\n    var click_"+model.getId().replace(".", "DOT")+" = function(e, modId) {showDiagramOptions(\"";
				script += clickEvent;
				script += "\", e, modId)}\n</script>";
		}
		
		if(clickFound == true) {
			return script;
		} else {
			return "";
		}
	}
}
