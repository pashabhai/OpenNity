package com.hsbc.plugin.utils;

import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;


import javax.imageio.ImageIO;

import com.vp.plugin.ApplicationManager;
import com.vp.plugin.DatabaseManager;
import com.vp.plugin.ExportDiagramAsImageOption;
import com.vp.plugin.VPPluginInfo;
import com.vp.plugin.diagram.IBusinessProcessDiagramUIModel;
import com.vp.plugin.diagram.IDiagramElement;
import com.vp.plugin.diagram.IDiagramUIModel;
import com.vp.plugin.diagram.IShapeUIModel;
import com.vp.plugin.model.DatabaseType;
import com.vp.plugin.model.IBPProcedure;
import com.vp.plugin.model.IBPProcedureStep;
import com.vp.plugin.model.IBPSubProcess;
import com.vp.plugin.model.IBPTask;
import com.vp.plugin.model.IBusinessRule;
import com.vp.plugin.model.IBusinessRuleGroup;
import com.vp.plugin.model.IDiagramOverview;
import com.vp.plugin.model.IHasChildrenBaseModelElement;
import com.vp.plugin.model.IHasRelationshipBaseSimpleRelationship;
import com.vp.plugin.model.IModelElement;
import com.vp.plugin.model.INoChildrenBaseModelElement;
import com.vp.plugin.model.IProject;
import com.vp.plugin.model.IReference;
import com.vp.plugin.model.IStereotype;
import com.vp.plugin.model.ITaggedValueContainer;
import com.vp.plugin.model.IUseCase;

public class DiagramGenerator {

	public static String createFeedbackSnippet() {
		String feedbackHtml = "";


		return feedbackHtml;
	}

	public static String generateImageMap(IDiagramUIModel diag, Collection<String> diagrams) {
		IProject project = ApplicationManager.instance().getProjectManager().getProject();
		
		VPPluginInfo[] pluginInfo = ApplicationManager.instance().getPluginInfos();
		
		String pluginDir = "";
		
		for(VPPluginInfo plugin : pluginInfo) {
			if(plugin.getPluginId().equals("com.hsbc.plugin")) {
				pluginDir = plugin.getPluginDir().getAbsolutePath();
			}
		}
		
		IModelElement root = ModelHelper.getRootModel(diag.getParentModel());

		String diagramImageTemplate = "";
		
		diagramImageTemplate = HtmlTemplate.loadFileContents(pluginDir + "/lib/webDiagramTemplate.html");
		
		String template = diagramImageTemplate;

		IDiagramElement[] el = diag.toDiagramElementArray();
		IModelElement model = null;
		Set<String> uniqueDiagramElements = new HashSet<String>();

		//prevent recursion
		if(diagrams!=null)
		{
			if(diagrams.contains(diag.getId()))
				return null;
			diagrams.add(diag.getId());
		}

		String imageMap = "";

		//re-order elements based on zOrder
		int iMax = 0;
		for(int i=0;i<el.length;i++)
		{
			if(iMax<el[i].getZOrder())
				iMax = el[i].getZOrder();
		}
		IDiagramElement[] newEl = new IDiagramElement[el.length];
		int iCount=0;
		for(int j=0;j<iMax+1;j++)
		{
			for(int i=0;i<el.length;i++)
			{
				if(el[i].getZOrder()==j)
				{
					newEl[iCount] = el[i];
					iCount++;
				}
			}			
		}
		el = newEl;

		String click = "";
		String clickEvent = "";
		boolean clickFound = false;
		
		//Pass rectangle to the export diagram as image option to return the cropped offset of the diagram
		Rectangle bounds = new Rectangle();
		ExportDiagramAsImageOption options = new ExportDiagramAsImageOption(ExportDiagramAsImageOption.IMAGE_TYPE_PNG);
		options.setTextAntiAliasing(true);
		//options.setTextAntiAliasing(false);
		Image img = ApplicationManager.instance().getModelConvertionManager().exportDiagramAsImage(diag, options, bounds);

		try {
			ImageIO.write((BufferedImage)img, "png",new File(pluginDir+"/website/it/diagram/"+"diag_"+diag.getId()+".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}	

		boolean line = false;
		//loop around elements on page
		if(el != null) {

		}
		for(int i=0;i<el.length;i++)
		{
			if(el[i] != null) {
				if(el[i].getModelElement() != null) {
					uniqueDiagramElements.add(el[i].getModelElement().getId());
				}

				line = false;

				if(el[i]==null)
					continue;
				model = el[i].getModelElement();
				if(model==null || model.getName()==null)
					continue;


				try {
					IHasRelationshipBaseSimpleRelationship childEl = null;
					childEl = ((IHasRelationshipBaseSimpleRelationship)model);
					line = true;
				} catch(Exception f) {
					//failed to cast
					line = false;
				}

				click = "";
				clickEvent = "<script>\n    var click_"+model.getId().replace(".", "DOT")+" = function(e, modId) {showDiagramOptions(\"";
				clickFound = false;

				if(model.getModelType()=="DiagramOverview")
				{
					clickFound = true;
					IDiagramUIModel refDiag = project.getDiagramById(((IDiagramOverview)model).getDiagramId());

					if(refDiag==null)
						continue;

					//create sub diagram
					if(diagrams!=null && diagrams.size() != 0) {
						generateImageMap(refDiag, diagrams);
						diagrams.remove(refDiag.getId());
					}

					String refDiagName = refDiag.getName();
					refDiagName = refDiagName.replace("\"", "\\\\\"");
					//add diagram to pop up
					clickEvent += refDiag.getId()+"~"+refDiagName +";";				
				}
				else
				{
					//check for references
					IReference[] ref = null;
					try {
						IHasChildrenBaseModelElement childEl = null;
						childEl = ((IHasChildrenBaseModelElement)model);
						ref = childEl.toReferenceArray();
					} catch(Exception e) {
						//failed to cast
						try {
							IHasRelationshipBaseSimpleRelationship childEl = null;
							childEl = ((IHasRelationshipBaseSimpleRelationship)model);
							ref = childEl.toReferenceArray();
						} catch(Exception f) {
							//failed to cast
							try {
								INoChildrenBaseModelElement childEl = null;
								childEl = ((INoChildrenBaseModelElement)model);
								ref = childEl.toReferenceArray();	
							} catch(Exception g) {
								System.out.println("Problem casting to class type:"+model.getModelType());
								continue;
							}
						}
					}
					if(ref!=null)
					{
						for(int r=0;r<ref.length;r++)
						{
							if(ref[r].getType()==2)
							{
								clickFound = true;
								IDiagramUIModel refDiag = ref[r].getUrlAsDiagram();

								//check diagram is active
								if(refDiag!=null)
								{
									//Check if reference is to the active diagram and ignore if is
									if(!refDiag.getId().equals(diag.getId())) {
										//create sub diagram
										if(diagrams!=null && diagrams.size() != 0) {
											generateImageMap(refDiag, diagrams);
											diagrams.remove(refDiag.getId());
										}

										String refDiagName = refDiag.getName();
										refDiagName = refDiagName.replace("\"", "\\\\\"");
										//add diagram to pop up
										clickEvent += refDiag.getId()+"~"+refDiagName+";";
									}
								}
							}
							else if(ref[r].getType()==1)
							{
								clickFound = true;
								String refDiag = ref[r].getUrl();

								//check diagram is active
								if(refDiag!=null)
								{
									//add diagram to pop up
									clickEvent += refDiag+";";
								}							
							}
						}
					}				
				}
				clickEvent += "\", e, modId)}\n</script>";
				if(line == false && clickFound == true) {
					click = "onmousedown=\"return click_"+model.getId().replace(".", "DOT")+"(event, '"+model.getId()+"')\"";
					imageMap += clickEvent;

					int left = 0;
					int top = 0;
					int right = 0;
					int bottom = 0;

					//Use bounds from exported diagram to adjust coordinates for cropped images
					int offSetX = (int)bounds.getX();
					int offSetY = (int)bounds.getY();

					left = el[i].getX() - offSetX;
					top = el[i].getY() - offSetY;
					right = left + el[i].getWidth();
					bottom = top + el[i].getHeight();

					String documentation = "";
					if(model.getDescription()!=null && !model.getDescription().equals("")){
						documentation = model.getDescription();
						//Escape $ sign in model documentation
						documentation = documentation.replace("$", "\\$");
						documentation = documentation.replace("\"", "&quot;");
					}
					imageMap += "<area style=\"cursor:pointer;\" shape=\"rect\" coords=\""+left+","+top+","+right+","+bottom+"\" "+click+" title=\""+ documentation +"\" alt=\"Sun\">";
				}
			}
		}
		String table = "";
		if(diag.getType().equals("ERDiagram")) {
			try {
				IDiagramElement[] elems = diag.toDiagramElementArray();
				IModelElement[] tables = new IModelElement[1];
				tables[0] = elems[0].getModelElement();
				DatabaseManager dm = ApplicationManager.instance().getDatabaseManager();
				String ddl = dm.generateCreateSQL(DatabaseType.MySQL_505, tables);
				ddl = ddl.replaceAll("<", "&lt;");
				ddl = ddl.replaceAll(">", "&gt;");
				table = "<pre>" + ddl + "</pre><br>";
			} catch (Exception e) {
				table = "";
			}
		} else if(diag.getType().equals("BusinessProcessDiagram")) {
			table += createBPTableHTML(diag);
			if(!table.equals("")) {
				table += "<br>";
				table += createBusinessRuleTable(diag);
			} else {
				table += createBusinessRuleTable(diag);
			}
		} else if(diag.getName().indexOf("Context Diagram") != -1 && diag.getParentModel().getName().equals("Context Diagram")) {
			table = createUseCaseTableHTML(diag);	
		} else {
			table = createTableHTML(diag);
		} 

		table = table.replace("$", "\\$");
		String doc = "";
		if(diag.getHtmlDocumentation()!=null)
			doc = diag.getHtmlDocumentation().replaceAll("<p>", "").replaceAll("</p>", "<br/>");
		
		template = template.replaceAll("##diagram_documentation##", doc);
		template = template.replaceAll("##diagram_image_map##", imageMap);
		Long timeStamp = System.currentTimeMillis();
		template = template.replaceAll("##diagram_image_id##", "diag_"+diag.getId()+".png?id=" + timeStamp);
		template = template.replaceAll("##diagram_table##", table);
		if(table.equals("")) {
			template = template.replaceAll("##display_table##", "style=\"display: none;\"");
		} else {
			template = template.replaceAll("##display_table##", "");
		}
		
		if(root.getName().equals("_Projects") || root.getName().equals("_Changes") || root.getName().equals("_Continual Projects") ){
			template = template.replaceAll("##diagram_id##", diag.getId());
		} else {
			template = template.replaceAll("##diagram_id##", "");
		}

		String fileName = pluginDir+"/website/it/diagram/"+"diag_"+diag.getId()+".html";
		HtmlTemplate.writeToFile(fileName, template);

		return imageMap;
	}
	
	public static String createUseCaseTableHTML(IDiagramUIModel diag) {
		String table = "";
		IModelElement useCaseOverviewModel = diag.getParentModel().getParent().getChildByName("Use Case Overview");
		IModelElement[] usecaseOverviewModel = useCaseOverviewModel.toChildArray("Model");

		ArrayList<IModelElement> usecaseList = new ArrayList<IModelElement>();
		Set<IModelElement> overviewList = new HashSet<IModelElement>();
		table = "<text><b>Use Cases</b><br><br></text><table>";
		table += "<tr><td><b>Work Package</b></td><td><b>Use Case</b></td><td><b>Use Case Jira</b></td></tr>";
		IDiagramElement[] diagElems = diag.toDiagramElementArray();

		for(IModelElement usecaseOverview : usecaseOverviewModel) {
			IModelElement[] usecases = usecaseOverview.toChildArray("UseCase");
			IDiagramUIModel[] diags = usecaseOverview.toSubDiagramArray();
			IDiagramUIModel overviewDiag = diags[0];
			for(IModelElement usecase : usecases) {
				String overviewName = usecaseOverview.getName();
				overviewName = overviewName.substring(overviewName.lastIndexOf("Use Case Overview") + 17, overviewName.length());
				overviewName = overviewName.replace("_", "");
				if(overviewName.equals("")) {
					overviewName = "Phase 1";
				}
				table += "<tr><td><a href=\"/it/diagram/diag_" + overviewDiag.getId() + ".html\">" + overviewName + "</a></td>";
				usecaseList.add(usecase);
				overviewList.add(usecase.getParent());

				IUseCase ucModel = (IUseCase)usecase;

				if(ucModel.referenceCount() != 0) {
					IReference[] refs = ucModel.toReferenceArray();

					IDiagramUIModel ucDiag = null;
					for(IReference ref : refs) {
						if(ref.getUrlAsDiagram() != null && ref.getUrlAsDiagram().getName() != null) {
							if(ref.getUrlAsDiagram().getName().indexOf("UC-") != -1) {
								ucDiag = ref.getUrlAsDiagram();
							}
						}
					}

					if(ucDiag != null) {
						IModelElement usecaseModel = ucDiag.getParentModel();
						if(usecaseModel == null)
							continue;
						ITaggedValueContainer tags = usecaseModel.getTaggedValues();
						String usecaseJiraId = "";
						if(tags != null) {
							if(tags.getTaggedValueByName("JIRA ID") != null && !tags.getTaggedValueByName("JIRA ID").getValueAsString().equals("")) {
								usecaseJiraId = tags.getTaggedValueByName("JIRA ID").getValueAsString();
							}
						}

						table += "<td><a href=\"/it/diagram/diag_" + ucDiag.getId() + ".html\">" + usecase.getName() + "</a></td>";
						if(!usecaseJiraId.equals("")) {
							table += "<td><a target=\"_blank\" href=\"https://geopost.jira.com/browse/" + usecaseJiraId + "\">" + usecaseJiraId + "</a></td>";
							table += "</tr>";
						} else {
							table += "<td>&nbsp;</td>";
							table += "</tr>";
						}

					} 
				} else {
					table += "<td>" + usecase.getName() + "</td>";
					table += "<td>&nbsp;</td>";
					table += "</tr>";
				}
			}
		}

		table += "</table>";
		return table;
	}

	public static String createBPTableHTML(IDiagramUIModel diagram) {
		String html = "";
		IBusinessProcessDiagramUIModel bpDiagram = (IBusinessProcessDiagramUIModel)diagram;

		IShapeUIModel[] elems = bpDiagram.toShapeUIModelArrayInBusinessProcessFlow();

		Collection<IModelElement> bpTasks = new ArrayList<IModelElement>();

		if(elems != null) {
			for(int i =0 ; i< elems.length; i++) {
				if(elems[i].getModelElement() != null && elems[i].getModelElement().getModelType().equals("BPTask")) {
					IBPTask task = (IBPTask)elems[i].getModelElement();
					if(((task.getHTMLDescription() != null && !task.getHTMLDescription().equals("")) || task.bpProcedureCount() > 0)) {
						bpTasks.add(elems[i].getModelElement());
					}
				}
				if(elems[i].getModelElement() != null && elems[i].getModelElement().getModelType().equals("BPSubProcess")) {
					IBPSubProcess task = (IBPSubProcess)elems[i].getModelElement();
					if(((task.getHTMLDescription() != null && !task.getHTMLDescription().equals("")) || task.bpProcedureCount() > 0)) {
						bpTasks.add(elems[i].getModelElement());
					}
				}
			}
		}

		if(bpTasks.size() != 0) {
			html += "<text><b>Tasks</b></text>";
			html += "<table style=\"width:100%\">";
			for(IModelElement bptask : bpTasks) {
				String documentation = "";
				if(bptask.getHTMLDescription() != null && !bptask.getHTMLDescription().equals("")) {
					documentation = bptask.getHTMLDescription();
				}
				IBPTask task = null;
				IBPSubProcess subProcess = null;
				if(bptask.getModelType().equals("BPTask")) {
					task = (IBPTask)bptask;
				}
				if(bptask.getModelType().equals("BPSubProcess")) {
					subProcess = (IBPSubProcess)bptask;
				}

				IBPProcedure[] bpProcedures = null;

				if(task != null) {
					if(task.toBpProcedureArray() != null) {
						bpProcedures = task.toBpProcedureArray();
					}
				}
				if(subProcess != null) {
					if(subProcess.toBpProcedureArray() != null) {
						bpProcedures = subProcess.toBpProcedureArray();
					}
				}
				String procedureHtml = "";
				if(bpProcedures!=null) {
					for(int j =0; j<bpProcedures.length; j++) {
						bpProcedures[j].bpProcedureStepCount();
						Iterator<IBPProcedureStep> iter = bpProcedures[j].bpProcedureStepIterator();
						Integer procedureStep = 0;
						String tab = "";
						String procedureName = "<b>" + bpProcedures[j].getName() + "</b><br>";
						String numbering = "";
						while(iter.hasNext())
						{
							procedureStep ++;
							IBPProcedureStep bpProcedureStep = iter.next();
							numbering = procedureStep.toString() + ".";
							procedureName += "<b>" + numbering + "</b>  " + bpProcedureStep.getName() + "<br>";
							if(bpProcedureStep.stepCount() > 0) {
								tab += "&nbsp;&nbsp;&nbsp;&nbsp;";
								procedureName += step(bpProcedureStep, tab, numbering);
							}
						}
						procedureHtml += procedureName + "<br>\n";
					}
				}

				String procedures = "";
				if(!documentation.equals("") && documentation != null) {
					procedures = "<br><br>" + procedureHtml;
				} else {
					procedures = procedureHtml.replaceAll("<p>", "").replaceAll("</p>", "<br/>");
				}

				if(!documentation.equals("") || !procedureHtml.equals("")) {
					html += "<tr><td valign='top' style=\"width:30%\"><a href='#' id='link_"+bptask.getId()+"' onclick='return false'></a>" + bptask.getName() + "</td>";
					html += "<td style=\"width:70%\">" + documentation.replaceAll("<p>", "").replaceAll("</p>", "<br/>") + procedures + "</td></tr>";
				}
			}
			html += "</table>";
		}
		return html;
	}

	private static String createTableHTML(IDiagramUIModel diagram) {
		String html = "";
		IDiagramElement[] diagElems = diagram.toDiagramElementArray();
		Set<String> modelTypes = new HashSet<String>();
		Collection<Collection> collectionsOfTypes = orderByType(diagElems);
		for(Collection coll : collectionsOfTypes) {
			if(coll.size() != 0) {
				Object[] elems = coll.toArray();
				String stereotype = "";
				IModelElement strModel = (IModelElement)elems[0];


				if(strModel.stereotypeCount() != 0) {
					IStereotype[] stereotypes = strModel.toStereotypeModelArray();
					if(stereotypes[0].getName() != null) {
						stereotype = stereotypes[0].getName();
					}
				}
				if(!stereotype.equals("")) {
					stereotype = stereotype.replace("<<", "");
					stereotype = stereotype.replace(">>", "");
					html += "<text><b>" + stereotype + "</b></text>";
				} else {
					html += "<text><b>" + strModel.getModelType() + "</b></text>";
				}
				html += "<table style=\"width:100%\">";
				for(Object elem : elems) {
					IModelElement modelElement = (IModelElement)elem;
					String script = ModelHelper.getModelReferences(modelElement, diagram.getId());
					html += "<tr><td valign='top' style=\"width:30%\"><a href='#' id='link_"+modelElement.getId()+"' onclick='return false'></a>" + script + "<a onmousedown=\"return click_"+modelElement.getId().replace(".", "DOT")+"(event, '"+modelElement.getId()+"')\">" + modelElement.getName() + "</a></td>";
					if(modelElement.getHTMLDescription() != null) {
						String doc = modelElement.getHTMLDescription();
						if(doc.indexOf("<body>") != -1) {
							doc = doc.substring(doc.indexOf("<body>"), doc.length());
							doc = doc.replaceAll("<body>", "");
							doc = doc.replaceAll("</body>", "");
							//doc = doc.replaceAll("<ul>", "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<ul>");
							doc = doc.replaceAll("<p>", "").replaceAll("</p>", "<br/>");
							html += "<td style=\"width:70%\">" + doc + "</td></tr>";
						}
					}
				}
				html += "</table>";
			}
		}
		return html;
	}

	public static String createBusinessRuleTable(IDiagramUIModel diagram) {
		String html = "";
		IDiagramElement[] diagElems = diagram.toDiagramElementArray();
		TreeMap<String, IBusinessRule> businessRules = new TreeMap<String, IBusinessRule>();
		for(IDiagramElement diagElem : diagElems) {
			IModelElement elem = diagElem.getModelElement();
			if(elem != null) {
				if(elem.getModelType() != null) {
					if(elem.getModelType().equals("BusinessRule")) {
						IBusinessRule br = (IBusinessRule)elem;
						businessRules.put(br.getUserID(), br);
					}
					if(elem.getModelType().equals("BusinessRuleGroup")) {
						IBusinessRuleGroup brGroup = (IBusinessRuleGroup)elem;
						IBusinessRule[] brs = brGroup.toBusinessRuleArray();
						for(IBusinessRule br : brs) {
							businessRules.put(br.getUserID(), br);
						}
					}
				}
			}
		}
		if(businessRules != null && businessRules.size() != 0) {
			html += "<text><b>Business Rules</b></text><br>";
			html += "<table style=\"width:100%\">";
			for(Map.Entry<String,IBusinessRule> businessRule : businessRules.entrySet()) {
				html += "<tr><td valign='top' style=\"width:10%\">" + businessRule.getKey().toString() + "</td>";
				html += "<td valign='top' style=\"width:20%\">" + businessRule.getValue().getName() + "</td>";
				if(businessRule.getValue().getRuleText() != null) {
					html += "<td valign='top' style=\"width:70%\">" + businessRule.getValue().getRuleText().replaceAll("\n", "<br><br>") + "<br><br></td></tr>";
				} else {
					html += "</tr>";
				}

			}
			html += "</table>";
		}
		html = html.replaceAll("\n", "<br>");
		return html;
	}	

	public static String step (IBPProcedureStep bpProcedureStep, String tab, String numbering) {
		Iterator<IBPProcedureStep> iter = bpProcedureStep.stepIterator();
		Integer subProcedureStep = 0;
		String subTab = tab;
		String subProcedureName = "";
		while(iter.hasNext())
		{
			subProcedureStep ++;
			IBPProcedureStep bpProcedureSubStep = iter.next();

			subProcedureName += "<b>" + subTab + numbering + subProcedureStep + ".</b>  " + bpProcedureSubStep.getName() + "<br>";
			if(bpProcedureSubStep.stepCount() > 0) {
				numbering += subProcedureStep + ".";
				subTab += "&nbsp;&nbsp;&nbsp;&nbsp;";
				subProcedureName += step(bpProcedureSubStep, subTab, numbering);
			}
		}
		return subProcedureName;
	}

	public static Collection orderByType(IDiagramElement[] diagElems) {

		Collection<Collection> col = new ArrayList<Collection>();

		Collection<IModelElement> beumers = new ArrayList<IModelElement>();
		Collection<IModelElement> voiceSystems = new ArrayList<IModelElement>();
		Collection<IModelElement> SP400Xs = new ArrayList<IModelElement>();
		Collection<IModelElement> IVRs = new ArrayList<IModelElement>();
		Collection<IModelElement> saturnScreens = new ArrayList<IModelElement>();
		Collection<IModelElement> hubInterfaces = new ArrayList<IModelElement>();
		Collection<IModelElement> webComponents = new ArrayList<IModelElement>();
		Collection<IModelElement> webPages = new ArrayList<IModelElement>();
		Collection<IModelElement> iphoneScreens = new ArrayList<IModelElement>();
		Collection<IModelElement> eCommerceComponents = new ArrayList<IModelElement>();
		Collection<IModelElement> gigPackets = new ArrayList<IModelElement>();
		Collection<IModelElement> realTimeDataTransfers = new ArrayList<IModelElement>();
		Collection<IModelElement> jasperComponents = new ArrayList<IModelElement>();

		Collection<IModelElement> esgAPIs = new ArrayList<IModelElement>();
		Collection<IModelElement> esgCodeChanges = new ArrayList<IModelElement>();
		Collection<IModelElement> redbackObjects = new ArrayList<IModelElement>();
		Collection<IModelElement> redbackMethods = new ArrayList<IModelElement>();
		Collection<IModelElement> hubRedbackObjects = new ArrayList<IModelElement>();
		Collection<IModelElement> hubRedbackMethods = new ArrayList<IModelElement>();
		Collection<IModelElement> depotPrograms = new ArrayList<IModelElement>();
		Collection<IModelElement> javaPrograms = new ArrayList<IModelElement>();
		Collection<IModelElement> universePrograms = new ArrayList<IModelElement>();
		Collection<IModelElement> salesforceScripts = new ArrayList<IModelElement>();
		Collection<IModelElement> talendPrograms = new ArrayList<IModelElement>();
		Collection<IModelElement> saturnProcesses = new ArrayList<IModelElement>();

		Collection<IModelElement> mySQLTables = new ArrayList<IModelElement>();
		Collection<IModelElement> mongoTables = new ArrayList<IModelElement>();
		Collection<IModelElement> depotFiles = new ArrayList<IModelElement>();
		Collection<IModelElement> universeFiles = new ArrayList<IModelElement>();
		Collection<IModelElement> universePackets = new ArrayList<IModelElement>();
		Collection<IModelElement> hubFiles = new ArrayList<IModelElement>();
		Collection<IModelElement> flatFiles = new ArrayList<IModelElement>();
		Collection<IModelElement> salesforceTables = new ArrayList<IModelElement>();

		Collection<IModelElement> trafficRules = new ArrayList<IModelElement>();
		Collection<IModelElement> applications = new ArrayList<IModelElement>();
		Collection<IModelElement> servers = new ArrayList<IModelElement>();
		Collection<IModelElement> networkAppliances = new ArrayList<IModelElement>();
		Collection<IModelElement> virtualMachines = new ArrayList<IModelElement>();
		Collection<IModelElement> containers = new ArrayList<IModelElement>();
		Collection<IModelElement> ansibleScripts = new ArrayList<IModelElement>();
		Collection<IModelElement> loadbalancerRules = new ArrayList<IModelElement>();
		Collection<IModelElement> bpTasks = new ArrayList<IModelElement>();

		Collection<IModelElement> modellingAutomations = new ArrayList<IModelElement>();
		Collection<IModelElement> modellingDiagramChanges = new ArrayList<IModelElement>();
		Collection<IModelElement> modellingMenuItems = new ArrayList<IModelElement>();
		Collection<IModelElement> modellingWebsiteChanges = new ArrayList<IModelElement>();

		Collection<IModelElement> others = new ArrayList<IModelElement>();

		String html = "";

		if(diagElems != null) {
			for(int i =0; i<diagElems.length; i++) {
				IModelElement diagModelElement = diagElems[i].getModelElement();
				if(diagModelElement==null || diagModelElement.getName()==null)
					continue;
				if(diagModelElement.getDescription() != null && !diagModelElement.getDescription().equals("")) {

					if(diagModelElement.hasStereotype("Beumer")) {
						saturnScreens.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Voice System")) {
						saturnScreens.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("SP400X")) {
						saturnScreens.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("IVR")) {
						saturnScreens.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Saturn Screen")) {
						saturnScreens.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Hub Interface")) {
						hubInterfaces.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Web Component")) {
						webComponents.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Web Page")) {
						webPages.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("IPhone Screen")) {
						iphoneScreens.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("eCommerce Component")) {
						eCommerceComponents.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("GIG Packet")) {
						gigPackets.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("RDT")) {
						realTimeDataTransfers.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Jasper")) {
						jasperComponents.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("ESG API")) {
						esgAPIs.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("ESG Code Changes")) {
						esgCodeChanges.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Redback Object")) {
						redbackObjects.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Redback Method")) {
						redbackMethods.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Hub Redback Object")) {
						hubRedbackObjects.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Hub Redback Method")) {
						hubRedbackMethods.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Depot Program")) {
						depotPrograms.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Java Program")) {
						javaPrograms.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Universe Program")) {
						universePrograms.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Salesforce Script")) {
						salesforceScripts.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Talend Program")) {
						talendPrograms.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Saturn Process")) {
						saturnProcesses.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("MySQL Table")) {
						mySQLTables.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Mongo Collection")) {
						mongoTables.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Depot File")) {
						depotFiles.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Universe File")) {
						universeFiles.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Universe Packet")) {
						universePackets.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Hub File")) {
						universePackets.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Flat File")) {
						universePackets.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Salesforce Table")) {
						salesforceTables.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Traffic Rule")) {
						trafficRules.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Application")) {
						applications.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Server")) {
						servers.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Network Appliance")) {
						networkAppliances.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Virtual Machine")) {
						virtualMachines.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Containers")) {
						containers.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Ansible Scripts")) {
						ansibleScripts.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Automation")) {
						modellingAutomations.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Diagram Change")) {
						modellingDiagramChanges.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Menu Item")) {
						modellingMenuItems.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Website Change")) {
						modellingWebsiteChanges.add(diagModelElement);
					}
					else if(diagModelElement.hasStereotype("Rule")) {
						loadbalancerRules.add(diagModelElement);
					} else {
						others.add(diagModelElement);
					}
				}
				else if(diagModelElement.getModelType().equals("BPTask")) {
					IBPTask task = (IBPTask)diagModelElement;
					if(((task.getDescription() != null && !task.getDescription().equals("")) || task.bpProcedureCount() > 0)) {
						bpTasks.add(diagModelElement);
					}
				} 
			}
		}

		col.add(beumers);
		col.add(voiceSystems);
		col.add(SP400Xs);
		col.add(IVRs);
		col.add(saturnScreens);
		col.add(hubInterfaces);
		col.add(webComponents);
		col.add(webPages);
		col.add(iphoneScreens);
		col.add(eCommerceComponents);
		col.add(gigPackets);
		col.add(realTimeDataTransfers);
		col.add(jasperComponents);
		col.add(esgAPIs);
		col.add(esgCodeChanges);
		col.add(redbackObjects);
		col.add(redbackMethods);
		col.add(hubRedbackObjects);
		col.add(hubRedbackMethods);
		col.add(depotPrograms);
		col.add(javaPrograms);
		col.add(universePrograms);
		col.add(salesforceScripts);
		col.add(talendPrograms);
		col.add(saturnProcesses);
		col.add(mySQLTables);
		col.add(mongoTables);
		col.add(depotFiles);
		col.add(universeFiles);
		col.add(universePackets);
		col.add(hubFiles);
		col.add(flatFiles);
		col.add(salesforceScripts);
		col.add(trafficRules);
		col.add(applications);
		col.add(servers);
		col.add(networkAppliances);
		col.add(virtualMachines);
		col.add(containers);
		col.add(ansibleScripts);
		col.add(loadbalancerRules);
		col.add(modellingAutomations);
		col.add(modellingDiagramChanges);
		col.add(modellingMenuItems);
		col.add(modellingWebsiteChanges);
		col.add(bpTasks);

		Collection<String> otherModelElemTypes = new ArrayList<String>();
		for(Object elem : others) {
			IModelElement modelElement = (IModelElement)elem;
			if(!otherModelElemTypes.contains(modelElement.getModelType())) {
				otherModelElemTypes.add(modelElement.getModelType());
			}
		}

		for(String elemType : otherModelElemTypes) {
			Collection<IModelElement> modelElements = new ArrayList<IModelElement>();
			for(Object elem : others) {
				IModelElement modelElement = (IModelElement)elem;
				if(modelElement.getModelType().equals(elemType)) {
					modelElements.add(modelElement);

				}
			}
			col.add(modelElements);
		}

		//col.add(others);

		return col;
	}

}